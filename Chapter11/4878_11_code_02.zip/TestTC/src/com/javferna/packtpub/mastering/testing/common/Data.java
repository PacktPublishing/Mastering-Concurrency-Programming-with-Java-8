package com.javferna.packtpub.mastering.testing.common;

public class Data {
	private int data;

	public int getData() {
		return data;
	}

	public void setData(int data) {
		this.data = data;
	}
	
	
}
